// components/whiteboard/canvas/GridBackground.tsx
import React from "react";

export function GridBackground() {
  return (
    <div
      className="pointer-events-none absolute inset-0"
      style={{
        backgroundImage:
          "linear-gradient(to right, rgba(148,163,184,0.15) 1px, transparent 1px), linear-gradient(to bottom, rgba(148,163,184,0.15) 1px, transparent 1px)",
        backgroundSize: "40px 40px",
      }}
    />
  );
}
