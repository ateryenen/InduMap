"use client";

import React from "react";
import type {
  Edge,
  EdgeRelation,
  EdgeStyle,
  Node,
} from "../../../lib/whiteboard/types";
import { EDGE_STYLE_PRESET as IMPORTED_PRESET } from "../../../lib/whiteboard/types";

type Point = { x: number; y: number };

export type EdgeLayerProps = {
  /** Back-compat: some callers pass nodes+edges */
  nodes?: Node[];
  edges?: Edge[];

  /** Newer callers may pass a center resolver */
  getNodeCenter?: (id: string) => Point;

  /** Optional: live preview line while dragging connect */
  connectingFrom?: Point | null;
  connectingTo?: Point | null;

  /** Optional: interactive edge clicking */
  onEdgeMouseDown?: (e: React.MouseEvent, edge: Edge) => void;
};

// Fallback preset (if import/export mismatch happens)
const FALLBACK_PRESET: Record<string, EdgeStyle> = {
  drives:      { arrow: "end", width: 2 },
  enables:     { arrow: "end", width: 2, dash: [6, 4] },
  blocks:      { arrow: "end", width: 2, dash: [2, 4] },
  dependsOn:   { arrow: "end", width: 2, dash: [8, 6] },
  tradeoff:    { arrow: "both", width: 2 },
  partOf:      { arrow: "end", width: 1 },
  childOf:     { arrow: "end", width: 1, dash: [4, 4] },
  similar:     { arrow: "none", width: 1, dash: [6, 6] },
  exampleOf:   { arrow: "end", width: 1, dash: [2, 6] },
  unspecified: { arrow: "end", width: 1 },
};

function getStyle(relation?: EdgeRelation, edgeStyle?: EdgeStyle): EdgeStyle {
  const presetMap: any = (IMPORTED_PRESET as any) ?? FALLBACK_PRESET;
  const preset = relation && presetMap?.[relation] ? presetMap[relation] : {};
  return { ...preset, ...(edgeStyle ?? {}) };
}

function safeNum(n: any, fallback: number) {
  return Number.isFinite(n) ? n : fallback;
}

/** Compute node center from Node definition (x,y,width,height). */
function centerFromNode(n?: Partial<Node>): Point {
  const x = safeNum((n as any)?.x, 0);
  const y = safeNum((n as any)?.y, 0);
  const w = safeNum((n as any)?.width, 0);
  const h = safeNum((n as any)?.height, 0);
  return { x: x + w / 2, y: y + h / 2 };
}

export default function EdgeLayer(props: EdgeLayerProps) {
  const {
    nodes = [],
    edges = [],
    getNodeCenter,
    connectingFrom = null,
    connectingTo = null,
    onEdgeMouseDown,
  } = props;

  // Build a map so we can resolve centers even if getNodeCenter isn't provided.
  const nodeMap = React.useMemo(() => {
    const m = new Map<string, Node>();
    for (const n of nodes) m.set((n as any).id, n);
    return m;
  }, [nodes]);

  const resolveCenter = React.useCallback(
    (id: string): Point => {
      if (typeof getNodeCenter === "function") return getNodeCenter(id);
      const n = nodeMap.get(id);
      return centerFromNode(n as any);
    },
    [getNodeCenter, nodeMap]
  );

  return (
    <svg className="absolute inset-0">
      <defs>
        <marker
          id="wb_arrow"
          viewBox="0 0 10 10"
          refX="10"
          refY="5"
          markerWidth="6"
          markerHeight="6"
          orient="auto-start-reverse"
        >
          <path d="M 0 0 L 10 5 L 0 10 z" fill="#334155" />
        </marker>
      </defs>

      {/* Existing edges */}
      {edges.map((edge) => {
        const from = resolveCenter((edge as any).fromId ?? (edge as any).from);
        const to = resolveCenter((edge as any).toId ?? (edge as any).to);

        const style = getStyle((edge as any).relation, (edge as any).style);
        const dash = style.dash ? style.dash.join(",") : undefined;
        const stroke = style.stroke ?? "#334155";
        const width = style.width ?? 1.5;

        const midX = (from.x + to.x) / 2;
        const midY = (from.y + to.y) / 2;

        const markerEnd =
          style.arrow === "end" || style.arrow === "both" ? "url(#wb_arrow)" : undefined;
        const markerStart = style.arrow === "both" ? "url(#wb_arrow)" : undefined;

        const interactive = !!onEdgeMouseDown && (style.interactive ?? true);

        return (
          <g key={(edge as any).id}>
            <line
              x1={from.x}
              y1={from.y}
              x2={to.x}
              y2={to.y}
              stroke={stroke}
              strokeWidth={width}
              strokeDasharray={dash}
              markerEnd={markerEnd}
              markerStart={markerStart}
              className={interactive ? "cursor-pointer" : undefined}
              style={{ pointerEvents: interactive ? "auto" : "none" }}
              onMouseDown={interactive ? (e) => onEdgeMouseDown?.(e, edge) : undefined}
            />
            {(edge as any).label ? (
              <text
                x={midX}
                y={midY - 6}
                textAnchor="middle"
                fontSize="10"
                fill="#0f172a"
                className="select-none"
                style={{ pointerEvents: "none" }}
              >
                {(edge as any).label}
              </text>
            ) : null}
          </g>
        );
      })}

      {/* Live preview line while dragging connect */}
      {connectingFrom && connectingTo ? (
        <line
          x1={connectingFrom.x}
          y1={connectingFrom.y}
          x2={connectingTo.x}
          y2={connectingTo.y}
          stroke="#64748b"
          strokeWidth={1.5}
          strokeDasharray="6,4"
          markerEnd="url(#wb_arrow)"
          style={{ pointerEvents: "none" }}
        />
      ) : null}
    </svg>
  );
}

// Named export for safety (some code may do import { EdgeLayer } ...)
export { EdgeLayer };