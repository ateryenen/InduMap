
"use client";

import React from "react";
import type { Edge } from "../lib/whiteboard/types";
import { EDGE_STYLE_PRESET } from "../lib/whiteboard/types";

type Props = {
  edges: Edge[];
  getNodeCenter: (id: string) => { x: number; y: number };
};

export default function EdgeLayer({ edges, getNodeCenter }: Props) {
  return (
    <svg className="absolute inset-0 pointer-events-none">
      {edges.map((edge) => {
        const from = getNodeCenter(edge.fromId);
        const to = getNodeCenter(edge.toId);

        const preset = EDGE_STYLE_PRESET[edge.relation] ?? {};
        const style = { ...preset, ...(edge.style ?? {}) };

        const dash = style.dash ? style.dash.join(",") : undefined;
        const stroke = style.stroke ?? "#334155";
        const width = style.width ?? 1.5;

        const midX = (from.x + to.x) / 2;
        const midY = (from.y + to.y) / 2;

        return (
          <g key={edge.id}>
            <line
              x1={from.x}
              y1={from.y}
              x2={to.x}
              y2={to.y}
              stroke={stroke}
              strokeWidth={width}
              strokeDasharray={dash}
              markerEnd={style.arrow === "end" || style.arrow === "both" ? "url(#arrow)" : undefined}
              markerStart={style.arrow === "both" ? "url(#arrow)" : undefined}
            />

            {edge.label && (
              <text
                x={midX}
                y={midY - 4}
                textAnchor="middle"
                fontSize="10"
                fill="#0f172a"
                className="select-none"
              >
                {edge.label}
              </text>
            )}
          </g>
        );
      })}

      <defs>
        <marker
          id="arrow"
          viewBox="0 0 10 10"
          refX="10"
          refY="5"
          markerWidth="6"
          markerHeight="6"
          orient="auto-start-reverse"
        >
          <path d="M 0 0 L 10 5 L 0 10 z" fill="#334155" />
        </marker>
      </defs>
    </svg>
  );
}
