// components/whiteboard/canvas/EdgeLayer.tsx
import React from "react";
import type { Node, Edge, EdgeRelation } from "../../../lib/whiteboard/types";

interface EdgeLayerProps {
  nodes: Node[];
  edges: Edge[];
  selectedEdgeId: string | null;
  onEdgeMouseDown: (
    e: React.MouseEvent<SVGLineElement>,
    edge: Edge
  ) => void;
}

function getRelationStyle(relation?: EdgeRelation) {
  switch (relation) {
    case "drives":
      return {
        stroke: "#16a34a", // 綠色：驅動
        strokeDasharray: "0",
      };
    case "blocks":
      return {
        stroke: "#dc2626", // 紅色：阻礙
        strokeDasharray: "6 4",
      };
    case "dependsOn":
      return {
        stroke: "#2563eb", // 藍色：依賴
        strokeDasharray: "4 4",
      };
    case "childOf":
      return {
        stroke: "#7c3aed", // 紫色：子策略
        strokeDasharray: "2 4",
      };
    case "similar":
      return {
        stroke: "#0f766e", // 青色：同類
        strokeDasharray: "2 2",
      };
    case "unspecified":
    default:
      return {
        stroke: "#64748b", // 預設灰色
        strokeDasharray: "0",
      };
  }
}

function getRelationLabel(relation?: EdgeRelation) {
  switch (relation) {
    case "drives":
      return "驅動";
    case "blocks":
      return "阻礙";
    case "dependsOn":
      return "依賴";
    case "childOf":
      return "子策略";
    case "similar":
      return "同類";
    case "unspecified":
    default:
      return "關聯";
  }
}

export function EdgeLayer({
  nodes,
  edges,
  selectedEdgeId,
  onEdgeMouseDown,
}: EdgeLayerProps) {
  if (!edges.length) return null;

  const nodeMap = new Map<string, Node>();
  nodes.forEach((n) => nodeMap.set(n.id, n));

  return (
    <svg className="pointer-events-none absolute inset-0 overflow-visible">
      <defs>
        <marker
          id="edge-arrow"
          viewBox="0 0 10 10"
          refX={8}
          refY={5}
          markerWidth={6}
          markerHeight={6}
          orient="auto-start-reverse"
        >
          <path d="M 0 0 L 10 5 L 0 10 z" fill="#64748b" />
        </marker>
      </defs>

      {edges.map((edge) => {
        const from = nodeMap.get(edge.fromId);
        const to = nodeMap.get(edge.toId);
        if (!from || !to) return null;

        const x1 = from.x + from.width / 2;
        const y1 = from.y + from.height / 2;
        const x2 = to.x + to.width / 2;
        const y2 = to.y + to.height / 2;

        const { stroke, strokeDasharray } = getRelationStyle(edge.relation);
        const isSelected = edge.id === selectedEdgeId;

        const midX = (x1 + x2) / 2;
        const midY = (y1 + y2) / 2;

        const handleMouseDown = (e: React.MouseEvent<SVGLineElement>) => {
          e.stopPropagation();
          onEdgeMouseDown(e, edge);
        };

        return (
          <g key={edge.id} className="pointer-events-auto">
            <line
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke="transparent"
              strokeWidth={14}
              onMouseDown={handleMouseDown}
            />

            <line
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke={stroke}
              strokeWidth={isSelected ? 3 : 2}
              strokeDasharray={strokeDasharray}
              markerEnd="url(#edge-arrow)"
            />

            <rect
              x={midX - 32}
              y={midY - 9}
              width={64}
              height={18}
              rx={4}
              className="fill-slate-900/80"
            />
            <text
              x={midX}
              y={midY}
              textAnchor="middle"
              dominantBaseline="middle"
              fontSize={10}
              className="fill-slate-50"
            >
              {edge.label?.trim() || getRelationLabel(edge.relation)}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
