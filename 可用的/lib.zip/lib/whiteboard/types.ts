// Auto-generated from page.tsx top-level types & constants

export type Tool =
  | "select"
  | "pan"
  | "connect"
  | "category"
  | "note"
  | "text"
  | "image"
  | "table";

export type NodeType = "category" | "note" | "text" | "image" | "table";

export type StrategyLevel = "L1" | "L2" | "L3" | "Info";

export interface TableData {
  rows: number;
  cols: number;
  cells: string[][];
}

export interface Node {
  id: string;
  type: NodeType;
  x: number;
  y: number;
  width: number;
  height: number;
  text?: string;
  bgColor?: string;
  imageUrl?: string; // dataURL 或線上 URL
  imageFile?: string; // .lmwb內部檔名，例如 "images/xxx.png"
  table?: TableData;
  fontSize?: number;
  groupId?: string;
  locked?: boolean;

  // 策略相關欄位
  level?: StrategyLevel;
  categoryTag?: string;
  impact?: number;
  effort?: number;
  owner?: string;
}

export type EdgeRelation =
  | "drives"      // 驅動
  | "blocks"      // 阻礙
  | "dependsOn"   // 依賴
  | "childOf"     // 子策略
  | "similar"     // 同類 / 關聯
  | "unspecified"; // 暫未定義

export interface Edge {
  id: string;
  fromId: string;
  toId: string;
  relation?: EdgeRelation; // 新增：連線語義
  label?: string;          // 新增：自訂說明文字
}


export interface Viewport {
  x: number;
  y: number;
  scale: number;
}

export interface BoardState {
  nodes: Node[];
  edges: Edge[];
  viewport: Viewport;
  projectName?: string;
}

// 多頁面專案結構
export interface Page {
  id: string;
  name: string;
  nodes: Node[];
  edges: Edge[];
  viewport: Viewport;
}

export interface ProjectFileV2 {
  version: 2;
  projectName: string;
  activePageId: string | null;
  pages: Page[];
}

export type ResizeHandle =
  | "top-left"
  | "top"
  | "top-right"
  | "right"
  | "bottom-right"
  | "bottom"
  | "bottom-left"
  | "left";

export const STORAGE_KEY = "industry-map-whiteboard-v3";

export function createId() {
  return `${Date.now().toString(36)}-${Math.random()
    .toString(36)
    .slice(2, 8)}`;
}

/** 初始產業圖譜模板節點 */
export const templateNodes: Node[] = [
  {
    id: "tpl-ai",
    type: "category",
    x: 100,
    y: 80,
    width: 260,
    height: 120,
    text: "AI 核心技術",
    bgColor: "#e0f2fe",
    fontSize: 14,
    level: "L1",
    categoryTag: "技術",
  },
  {
    id: "tpl-robot",
    type: "category",
    x: 460,
    y: 80,
    width: 260,
    height: 120,
    text: "機器人 / 自動化",
    bgColor: "#fef3c7",
    fontSize: 14,
    level: "L1",
    categoryTag: "應用",
  },
  {
    id: "tpl-edge",
    type: "category",
    x: 820,
    y: 80,
    width: 260,
    height: 120,
    text: "Edge Device / Sensor",
    bgColor: "#dcfce7",
    fontSize: 14,
    level: "L1",
    categoryTag: "裝置",
  },
  {
    id: "tpl-cloud",
    type: "category",
    x: 100,
    y: 260,
    width: 260,
    height: 120,
    text: "雲端平台 / MLOps",
    bgColor: "#ede9fe",
    fontSize: 14,
    level: "L2",
    categoryTag: "平台",
  },
  {
    id: "tpl-enterprise",
    type: "category",
    x: 460,
    y: 260,
    width: 260,
    height: 120,
    text: "企業應用場景",
    bgColor: "#fee2e2",
    fontSize: 14,
    level: "L2",
    categoryTag: "應用",
  },
  {
    id: "tpl-connect",
    type: "note",
    x: 880,
    y: 420,
    width: 220,
    height: 90,
    text: "連接層：5G / LPWAN / eSIM",
    bgColor: "#e5e7eb",
    fontSize: 12,
    level: "Info",
    categoryTag: "Connectivity",
  },
];

