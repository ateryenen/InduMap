// Auto-generated from page.tsx top-level types & constants

export type Tool =
  | "select"
  | "pan"
  | "connect"
  | "category"
  | "note"
  | "text"
  | "image"
  | "table";

export type NodeType = "category" | "note" | "text" | "image" | "table";

export type StrategyLevel = "L1" | "L2" | "L3" | "Info";

export interface TableData {
  rows: number;
  cols: number;
  cells: string[][];
}

// 0~1 正規化裁切框（相對於原圖）
export type ImageCrop = {
  x: number;
  y: number;
  w: number;
  h: number;
};

export interface Node {
  id: string;
  type: NodeType;
  x: number;
  y: number;
  width: number;
  height: number;
  text?: string;
  bgColor?: string;
  imageUrl?: string; // dataURL 或線上 URL
  imageFile?: string; // .lmwb內部檔名，例如 "images/xxx.png"
  imageCrop?: ImageCrop; // 0~1 正規化裁切框（相對於原圖）
  table?: TableData;
  fontSize?: number;
  groupId?: string;
  locked?: boolean;

  // 策略相關欄位
  level?: StrategyLevel;
  categoryTag?: string;
  impact?: number;
  effort?: number;
  owner?: string;
}

export type EdgeRelation =
  | "drives"      // 驅動
  | "blocks"      // 阻礙
  | "dependsOn"   // 依賴
  | "childOf"     // 子策略
  | "similar"     // 同類 / 關聯
  | "unspecified"; // 暫未定義

export interface Edge {
  id: string;
  fromId: string;
  toId: string;
  relation?: EdgeRelation; // 新增：連線語義
  label?: string;          // 新增：自訂說明文字
}


export interface Viewport {
  x: number;
  y: number;
  scale: number;
}

export interface BoardState {
  nodes: Node[];
  edges: Edge[];
  viewport: Viewport;
  projectName?: string;
}

// 多頁面專案結構
export interface Page {
  id: string;
  name: string;
  nodes: Node[];
  edges: Edge[];
  viewport: Viewport;
}

export interface ProjectFileV2 {
  version: 2;
  projectName: string;
  activePageId: string | null;
  pages: Page[];
}

export type ResizeHandle =
  | "top-left"
  | "top"
  | "top-right"
  | "right"
  | "bottom-right"
  | "bottom"
  | "bottom-left"
  | "left";

export const STORAGE_KEY = "industry-map-whiteboard-v3";

export function createId() {
  return `${Date.now().toString(36)}-${Math.random()
    .toString(36)
    .slice(2, 8)}`;
}

/** 初始產業圖譜模板節點 */
export const templateNodes: Node[] = [
  {
    id: "tpl-ai",
    type: "category",
    x: 100,
    y: 80,
    width: 260,
    height: 120,
    text: "AI 核心技術",
    bgColor: "#e0f2fe",
    fontSize: 14,
    level: "L1",
    categoryTag: "技術",
  },
  {
    id: "tpl-robot",
    type: "category",
    x: 460,
    y: 80,
    width: 260,
    height: 120,
    text: "機器人 / 自動化",
    bgColor: "#fef3c7",
    fontSize: 14,
    level: "L1",
    categoryTag: "應用",
  },
  {
    id: "tpl-edge",
    type: "category",
    x: 820,
    y: 80,
    width: 260,
    height: 120,
    text: "Edge Device / Sensor",
    bgColor: "#dcfce7",
    fontSize: 14,
    level: "L1",
    categoryTag: "裝置",
  },
  {
    id: "tpl-cloud",
    type: "category",
    x: 100,
    y: 260,
    width: 260,
    height: 120,
    text: "雲端平台 / MLOps",
    bgColor: "#ede9fe",
    fontSize: 14,
    level: "L2",
    categoryTag: "平台",
  },
  {
    id: "tpl-enterprise",
    type: "category",
    x: 460,
    y: 260,
    width: 260,
    height: 120,
    text: "企業應用場景",
    bgColor: "#fee2e2",
    fontSize: 14,
    level: "L2",
    categoryTag: "應用",
  },
  {
    id: "tpl-connect",
    type: "note",
    x: 880,
    y: 420,
    width: 220,
    height: 90,
    text: "連接層：5G / LPWAN / eSIM",
    bgColor: "#e5e7eb",
    fontSize: 12,
    level: "Info",
    categoryTag: "Connectivity",
  },
];

// ===============================
// ===== Robot Strategy Template (Expanded) =====
// ===============================

export const robotTemplateNodes: Node[] = [
  // ===== 中央主體 =====
  {
    id: "rb_center",
    type: "category",
    x: 1700,
    y: 900,
    width: 640,
    height: 520,
    text: "具身智能機器人\n（核心系統）",
    bgColor: "#0b3a73",
    fontSize: 18,
    level: "L1",
    categoryTag: "核心",
  },

  // ===== 右側：大腦 / 小腦 / 資料 =====
  {
    id: "rb_brain",
    type: "category",
    x: 2550,
    y: 330,
    width: 620,
    height: 330,
    text: "大腦 / AI",
    bgColor: "#ffffff",
    fontSize: 16,
    level: "L1",
    categoryTag: "軟體",
  },
  {
    id: "rb_ctrl",
    type: "category",
    x: 2550,
    y: 710,
    width: 620,
    height: 360,
    text: "小腦 / 控制",
    bgColor: "#ffffff",
    fontSize: 16,
    level: "L1",
    categoryTag: "控制",
  },
  {
    id: "rb_data",
    type: "category",
    x: 2550,
    y: 1120,
    width: 620,
    height: 360,
    text: "資料 / 平台",
    bgColor: "#ffffff",
    fontSize: 16,
    level: "L1",
    categoryTag: "平台",
  },

  // 右側子項（大腦 / AI）
  { id: "rb_brain_1", type: "text", x: 2580, y: 400, width: 560, height: 70, text: "多模態：VLM / VLA / LLM", bgColor: "#f8fafc", fontSize: 12, level: "L2" },
  { id: "rb_brain_2", type: "text", x: 2580, y: 480, width: 560, height: 70, text: "推理：端側 / 雲端 / 協同", bgColor: "#f8fafc", fontSize: 12, level: "L2" },
  { id: "rb_brain_3", type: "text", x: 2580, y: 560, width: 560, height: 70, text: "工具/代理：規劃、RAG、調用", bgColor: "#f8fafc", fontSize: 12, level: "L2" },

  // 右側子項（小腦 / 控制）
  { id: "rb_ctrl_1", type: "text", x: 2580, y: 780, width: 560, height: 70, text: "運動控制：伺服、MPC、PID", bgColor: "#f8fafc", fontSize: 12, level: "L2" },
  { id: "rb_ctrl_2", type: "text", x: 2580, y: 860, width: 560, height: 70, text: "感知融合：SLAM / 定位 / 地圖", bgColor: "#f8fafc", fontSize: 12, level: "L2" },
  { id: "rb_ctrl_3", type: "text", x: 2580, y: 940, width: 560, height: 70, text: "規劃：路徑 / 抓取 / 避障", bgColor: "#f8fafc", fontSize: 12, level: "L2" },

  // 右側子項（資料 / 平台）
  { id: "rb_data_1", type: "text", x: 2580, y: 1190, width: 560, height: 70, text: "資料採集：感測/行為/回放", bgColor: "#f8fafc", fontSize: 12, level: "L2" },
  { id: "rb_data_2", type: "text", x: 2580, y: 1270, width: 560, height: 70, text: "運維：OTA / Fleet / 日誌", bgColor: "#f8fafc", fontSize: 12, level: "L2" },
  { id: "rb_data_3", type: "text", x: 2580, y: 1350, width: 560, height: 70, text: "雲端：API / Dashboard / 權限", bgColor: "#f8fafc", fontSize: 12, level: "L2" },

  // ===== 左側：執行 / 感測 / 能源 =====
  {
    id: "rb_act",
    type: "category",
    x: 820,
    y: 330,
    width: 720,
    height: 360,
    text: "執行器 / 關節",
    bgColor: "#ffffff",
    fontSize: 16,
    level: "L1",
    categoryTag: "硬體",
  },
  {
    id: "rb_sense",
    type: "category",
    x: 820,
    y: 730,
    width: 720,
    height: 360,
    text: "感測器",
    bgColor: "#ffffff",
    fontSize: 16,
    level: "L1",
    categoryTag: "硬體",
  },
  {
    id: "rb_power",
    type: "category",
    x: 820,
    y: 1130,
    width: 720,
    height: 300,
    text: "能源 / 電池",
    bgColor: "#ffffff",
    fontSize: 16,
    level: "L1",
    categoryTag: "電源",
  },

  // 左側子項（執行器）
  { id: "rb_act_1", type: "text", x: 860, y: 400, width: 640, height: 70, text: "伺服電機 / 驅動器", bgColor: "#f8fafc", fontSize: 12, level: "L2" },
  { id: "rb_act_2", type: "text", x: 860, y: 480, width: 640, height: 70, text: "減速器 / 關節模組", bgColor: "#f8fafc", fontSize: 12, level: "L2" },
  { id: "rb_act_3", type: "text", x: 860, y: 560, width: 640, height: 70, text: "靈巧手 / 末端執行器", bgColor: "#f8fafc", fontSize: 12, level: "L2" },

  // 左側子項（感測器）
  { id: "rb_sense_1", type: "text", x: 860, y: 800, width: 640, height: 70, text: "視覺：相機 / 深度 / ToF", bgColor: "#f8fafc", fontSize: 12, level: "L2" },
  { id: "rb_sense_2", type: "text", x: 860, y: 880, width: 640, height: 70, text: "IMU / 姿態 / 里程計", bgColor: "#f8fafc", fontSize: 12, level: "L2" },
  { id: "rb_sense_3", type: "text", x: 860, y: 960, width: 640, height: 70, text: "力覺 / 觸覺 / 扭矩", bgColor: "#f8fafc", fontSize: 12, level: "L2" },

  // 左側子項（能源 / 電池）
  { id: "rb_power_1", type: "text", x: 860, y: 1200, width: 640, height: 70, text: "電池 / BMS / 安規", bgColor: "#f8fafc", fontSize: 12, level: "L2" },
  { id: "rb_power_2", type: "text", x: 860, y: 1280, width: 640, height: 70, text: "充電 / 供電模組", bgColor: "#f8fafc", fontSize: 12, level: "L2" },
  { id: "rb_power_3", type: "text", x: 860, y: 1360, width: 640, height: 70, text: "功率元件 / 電源管理", bgColor: "#f8fafc", fontSize: 12, level: "L2" },
];

export const robotTemplateEdges: Edge[] = [
  // 主幹：中央 → 六大區塊
  { id: "e_center_brain", fromId: "rb_center", toId: "rb_brain", relation: "drives", label: "主幹" },
  { id: "e_center_ctrl",  fromId: "rb_center", toId: "rb_ctrl",  relation: "drives", label: "主幹" },
  { id: "e_center_data",  fromId: "rb_center", toId: "rb_data",  relation: "drives", label: "主幹" },
  { id: "e_center_act",   fromId: "rb_center", toId: "rb_act",   relation: "drives", label: "主幹" },
  { id: "e_center_sense", fromId: "rb_center", toId: "rb_sense", relation: "drives", label: "主幹" },
  { id: "e_center_power", fromId: "rb_center", toId: "rb_power", relation: "drives", label: "主幹" },

  // 分支：區塊 → 子項（大腦）
  { id: "e_brain_1", fromId: "rb_brain", toId: "rb_brain_1", relation: "dependsOn" },
  { id: "e_brain_2", fromId: "rb_brain", toId: "rb_brain_2", relation: "dependsOn" },
  { id: "e_brain_3", fromId: "rb_brain", toId: "rb_brain_3", relation: "dependsOn" },

  // 分支：區塊 → 子項（控制）
  { id: "e_ctrl_1", fromId: "rb_ctrl", toId: "rb_ctrl_1", relation: "dependsOn" },
  { id: "e_ctrl_2", fromId: "rb_ctrl", toId: "rb_ctrl_2", relation: "dependsOn" },
  { id: "e_ctrl_3", fromId: "rb_ctrl", toId: "rb_ctrl_3", relation: "dependsOn" },

  // 分支：區塊 → 子項（資料）
  { id: "e_data_1", fromId: "rb_data", toId: "rb_data_1", relation: "dependsOn" },
  { id: "e_data_2", fromId: "rb_data", toId: "rb_data_2", relation: "dependsOn" },
  { id: "e_data_3", fromId: "rb_data", toId: "rb_data_3", relation: "dependsOn" },

  // 分支：區塊 → 子項（執行器）
  { id: "e_act_1", fromId: "rb_act", toId: "rb_act_1", relation: "unspecified" },
  { id: "e_act_2", fromId: "rb_act", toId: "rb_act_2", relation: "unspecified" },
  { id: "e_act_3", fromId: "rb_act", toId: "rb_act_3", relation: "unspecified" },

  // 分支：區塊 → 子項（感測器）
  { id: "e_sense_1", fromId: "rb_sense", toId: "rb_sense_1", relation: "unspecified" },
  { id: "e_sense_2", fromId: "rb_sense", toId: "rb_sense_2", relation: "unspecified" },
  { id: "e_sense_3", fromId: "rb_sense", toId: "rb_sense_3", relation: "unspecified" },

  // 分支：區塊 → 子項（能源）
  { id: "e_power_1", fromId: "rb_power", toId: "rb_power_1", relation: "unspecified" },
  { id: "e_power_2", fromId: "rb_power", toId: "rb_power_2", relation: "unspecified" },
  { id: "e_power_3", fromId: "rb_power", toId: "rb_power_3", relation: "unspecified" },
];
